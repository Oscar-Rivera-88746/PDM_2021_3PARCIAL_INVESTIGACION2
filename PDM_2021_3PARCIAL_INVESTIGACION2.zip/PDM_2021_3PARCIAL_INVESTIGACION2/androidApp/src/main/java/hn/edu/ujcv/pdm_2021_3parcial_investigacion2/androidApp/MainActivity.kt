package hn.edu.ujcv.pdm_2021_3parcial_investigacion2.androidApp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import hn.edu.ujcv.pdm_2021_3parcial_investigacion2.shared.Greeting
import android.widget.TextView
import android.widget.Toast

fun greet(): String {
    return Greeting().greeting()
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var btnCalcular=findViewById<View>(R.id.btnCalcular) as Button
        btnCalcular.setOnClickListener { calcular()}
    }
    fun calcular (){
        var numero1=findViewById<View>(R.id.numero1) as EditText
        var numero2=findViewById<View>(R.id.numero2) as EditText
        var txtResultado=findViewById<View>(R.id.txtResultado) as TextView

        var resultado=etUno.text.toString().toDouble() * etDos.text.toString().toDouble()

        txtResultado.text = getString(R.string.resultado,resultado.toString())
    }
}







