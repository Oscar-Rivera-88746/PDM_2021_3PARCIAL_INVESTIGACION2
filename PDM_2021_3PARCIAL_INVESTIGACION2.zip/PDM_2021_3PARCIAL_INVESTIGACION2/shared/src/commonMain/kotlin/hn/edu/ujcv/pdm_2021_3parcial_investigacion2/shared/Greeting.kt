package hn.edu.ujcv.pdm_2021_3parcial_investigacion2.shared


class Greeting {
    fun greeting(): String {
        return "Hello, ${Platform().platform}!"
    }
}
