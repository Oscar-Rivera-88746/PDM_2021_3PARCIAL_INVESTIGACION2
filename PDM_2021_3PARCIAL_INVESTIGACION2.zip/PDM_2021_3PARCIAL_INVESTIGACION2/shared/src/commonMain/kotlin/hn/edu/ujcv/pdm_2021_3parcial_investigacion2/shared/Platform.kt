package hn.edu.ujcv.pdm_2021_3parcial_investigacion2.shared

expect class Platform() {
    val platform: String
}