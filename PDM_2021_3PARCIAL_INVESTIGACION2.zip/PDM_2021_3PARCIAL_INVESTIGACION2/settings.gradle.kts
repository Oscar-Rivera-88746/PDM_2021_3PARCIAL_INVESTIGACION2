pluginManagement {
    repositories {
        google()
        jcenter()
        gradlePluginPortal()
        mavenCentral()
    }
    
}
rootProject.name = "PDM_2021_3PARCIAL_INVESTIGACION2"


include(":androidApp")
include(":shared")

